
int make_paste(char* directory, char* paste_id, char* paste_content);



void get_random_data(unsigned char* buf, int n);

void print_hex_data(unsigned char* buf, int n);

void read_hex_data(unsigned char* buf, int n);

void mangle(unsigned char* input_buf, unsigned char* output_buf);


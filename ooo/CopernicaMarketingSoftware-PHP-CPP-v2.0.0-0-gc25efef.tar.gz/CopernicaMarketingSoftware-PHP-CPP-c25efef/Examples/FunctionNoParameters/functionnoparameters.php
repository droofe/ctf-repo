<?php
/**
 *  functionnoparameters.php
 *  @author Jasper van Eck<jasper.vaneck@copernica.com>
 * 
 *  An example file to show the working of a function call without parameters.
 */


//Run a function without parameters.  
echo my_no_parameters_function() . "\n";

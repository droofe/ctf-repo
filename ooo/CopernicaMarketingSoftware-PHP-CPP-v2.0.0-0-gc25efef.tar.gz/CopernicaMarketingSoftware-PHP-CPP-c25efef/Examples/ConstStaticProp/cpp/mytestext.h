/**
 *	The includes.h
 */
 
/**
 * 	Default Cpp libraries
 */
 
#include <string>
#include <iostream>

/**
 * 	Our own library.
 */
#include <phpcpp.h>

/**
 *  Namespace to use
 */
using namespace std;

/**
 * 	The test class.
 */
//#include "mycustomclass.h"
